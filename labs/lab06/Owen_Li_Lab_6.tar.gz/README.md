part a)My selection sort is stable because before swapping my code checks
        whether or not the iterators are pointing at the same node and whether
        or not the values at the iterators are equal.
        
part b)By using a pairs with the same value as their first element and comparing
        them,  I was able to determine that the sorting algortihm is stable.